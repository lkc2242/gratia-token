
# Gratia Token (GRTIA)

**Gratia** is a sovereign token minted under the divine treasury economy.

## Token Information
- Name: Gratia
- Symbol: GRTIA
- Decimals: 18
- Chain: Ethereum Mainnet
- Contract: `0xd3040104ccb3007a25f89106f5125d0ebf856bd`

## Features
- ✅ Forever Mintable
- ❌ No Burn
- ✅ 1% Transfer Tax sent to Treasury
- 🔐 Treasury Address: `0x46f73E15e4cd36f0E4DC4946fD219a687412C815`

This repo serves as the official metadata & asset registry for Gratia (GRTIA).
